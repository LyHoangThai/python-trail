# Write two print statements below
