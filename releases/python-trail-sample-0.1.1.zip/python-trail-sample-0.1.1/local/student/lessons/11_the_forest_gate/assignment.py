coins = 12
if coins >= 10:
    # Write your message here
    pass
