toys = ["ball", "robot", "kite"]
target = "robot"

def find_toy(toys, target):
    pass

print(find_toy(toys, target))
