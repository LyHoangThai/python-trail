stack = ["blue"]
plate = "red"
