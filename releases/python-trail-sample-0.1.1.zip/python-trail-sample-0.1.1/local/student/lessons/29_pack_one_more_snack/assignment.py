backpack = ["map"]
snack = "apple"
