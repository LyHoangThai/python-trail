snacks = 17
friends = 4
