class Pet:
    def speak(self):
        pass

# Make and greet your pet
