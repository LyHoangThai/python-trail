colors = ["red", "blue", "red"]
