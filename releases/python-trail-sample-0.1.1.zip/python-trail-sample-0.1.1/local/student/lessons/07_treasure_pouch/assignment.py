coins = 10
# Find 5 more coins
print(coins)
