hero = {}
# Read the name and level
