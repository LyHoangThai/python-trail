from collections import deque
people = ["Ari", "Bo"]
newcomer = "Cy"
