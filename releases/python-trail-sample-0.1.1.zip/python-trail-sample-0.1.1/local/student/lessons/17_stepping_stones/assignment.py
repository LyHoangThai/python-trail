# Count your steps
