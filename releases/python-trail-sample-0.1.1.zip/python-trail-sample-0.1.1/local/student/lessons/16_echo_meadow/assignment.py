for turn in range(3):
    pass
