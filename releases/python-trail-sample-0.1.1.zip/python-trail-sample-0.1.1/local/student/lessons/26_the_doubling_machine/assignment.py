number = 6

def double(number):
    pass

# Print what the machine gives back
