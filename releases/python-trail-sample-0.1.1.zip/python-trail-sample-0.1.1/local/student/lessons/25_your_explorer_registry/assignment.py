heroes = [{"name": "Pip", "level": 1}, {"name": "Nova", "level": 2}]

def introduce(hero):
    pass

# Introduce each hero
