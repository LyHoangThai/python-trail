def snacks():
    pass

# Collect and print each yielded snack
