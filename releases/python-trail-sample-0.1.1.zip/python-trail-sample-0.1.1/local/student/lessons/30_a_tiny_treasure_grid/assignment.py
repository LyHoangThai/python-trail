grid = [["rock", "coin"], ["key", "gem"]]
row = 1
column = 0
