graph = {"Ari": ["Bo", "Cy"], "Bo": ["Ari"], "Cy": ["Ari"]}
person = "Ari"
