from collections import deque
graph = {"home": ["shop"], "shop": ["park"], "park": []}
start = "home"
goal = "park"
# Explore in queue order
