bag = {"map": 1, "snack": 3}
