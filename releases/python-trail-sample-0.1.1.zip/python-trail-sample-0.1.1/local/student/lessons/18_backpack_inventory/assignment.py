backpack = ["map", "snack", "torch"]
