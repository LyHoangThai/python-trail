label = "  captain nova  "
# Tidy this name tag
