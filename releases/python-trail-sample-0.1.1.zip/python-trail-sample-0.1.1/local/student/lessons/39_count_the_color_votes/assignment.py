votes = ["red", "blue", "red"]
counts = {}
