raining = False
if raining:
    print("Bring a coat")
else:
    pass
