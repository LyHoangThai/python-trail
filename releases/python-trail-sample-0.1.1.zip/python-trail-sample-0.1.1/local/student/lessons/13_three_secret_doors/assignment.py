door = 2
if door == 1:
    print("A sleepy dragon")
# Add an elif for door 2
