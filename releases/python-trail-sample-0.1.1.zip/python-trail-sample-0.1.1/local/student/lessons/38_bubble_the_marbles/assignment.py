marbles = [3, 1, 2]
# Compare neighbors over repeated passes
