start = 3

def countdown(n):
    pass

countdown(start)
