score = 85
# 80 or more: Gold
# 50 or more: Silver
# Otherwise: Bronze
