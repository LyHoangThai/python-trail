explorers = ["Pip", "Nova", "Ash"]

def welcome(name):
    # Print a welcome using name
    pass

# Welcome each explorer with a loop
