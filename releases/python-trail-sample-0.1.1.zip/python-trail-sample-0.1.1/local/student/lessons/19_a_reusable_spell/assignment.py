def cheer():
    # Give your explorer a boost
    pass

# Call your function below
