name = ""
print(name)
