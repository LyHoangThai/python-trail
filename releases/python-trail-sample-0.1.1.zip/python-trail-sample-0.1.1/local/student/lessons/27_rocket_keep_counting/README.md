# 27 · Rocket, keep counting!

**Topic:** While loops · **Chapter:** 1

A `while` loop is like saying “keep going while this is true.” Change the counter each turn, or your rocket will count forever! A for loop visits items; a while loop watches a condition.

## Your assignment

Start count at 3. Use a while loop to print 3, 2, 1 on separate lines, then print Liftoff!.

The matching lesson number on the website is **27**. Its saved file is **assignment.py**. Use the browser simulator for PLC exercises.

## What this lesson checks

- Use a while loop with a changing count.
- Start at the given count and stop at zero.

Expected output:

```text
3
2
1
Liftoff!
```

## Learn and turn in through the browser

Open http://localhost:8766/lessons/27 for this lesson's instructions, code editor and output on one screen. Your browser draft saves automatically on this computer.

1. Write code in the browser editor.
2. Click **Run code** to try it. Running does not create a submission.
3. Click **Turn in assignment** when ready. It saves the code version, checks it, and gives you a submission ID.
4. If it needs revision, edit and turn it in again. Every attempt is saved.

Parents can review the history at http://localhost:8766/parent and open any attempt to see its source, result, output and changes from the previous attempt.

## Optional VS Code workflow

Edit assignment.py in this folder, save (Ctrl+S), then choose Tasks: Run Test Task → Trail: Turn in assignment in the Python Trail dev container. Ctrl+Shift+B only runs Python; it does not turn it in.

Browser drafts and optional assignment.py files are separate workspaces. Both submit to the same lesson history; neither overwrites the other's draft.

## Hint

Use while count > 0:, print count, and subtract 1 inside the loop.
