count = 3
# Count down while count is bigger than zero
