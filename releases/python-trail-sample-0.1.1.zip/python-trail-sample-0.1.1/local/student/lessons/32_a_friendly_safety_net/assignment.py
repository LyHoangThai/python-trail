text = "seven"
# Try the conversion and catch ValueError
