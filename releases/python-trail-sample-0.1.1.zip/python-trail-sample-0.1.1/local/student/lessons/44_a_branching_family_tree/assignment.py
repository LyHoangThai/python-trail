tree = {"name": "Oak", "children": [{"name": "Leaf A"}, {"name": "Leaf B"}]}
