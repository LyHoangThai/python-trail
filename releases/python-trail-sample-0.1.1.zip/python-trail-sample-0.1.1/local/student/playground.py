# Try your own Python idea here.
print("Hello, explorer!")
